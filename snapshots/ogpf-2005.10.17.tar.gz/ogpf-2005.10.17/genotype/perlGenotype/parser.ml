type token =
  | EOF
  | SEMI
  | SCALAR
  | LIST
  | WHILE
  | IDENT of (string)
  | BINARY_OP of (string)
  | LEFT_PAREN
  | RIGHT_PAREN
  | LEFT_CURLEY
  | RIGHT_CURLEY
  | LEFT_BRACKET
  | RIGHT_BRACKET
  | CONST of (string)

open Parsing;;
# 11 "genotype/perlGenotype/parser.mly"
  let debug msg =
    print_string msg;
    print_newline()
  let debug msg = ()
# 24 "genotype/perlGenotype/parser.ml"
let yytransl_const = [|
    0 (* EOF *);
  257 (* SEMI *);
  258 (* SCALAR *);
  259 (* LIST *);
  260 (* WHILE *);
  263 (* LEFT_PAREN *);
  264 (* RIGHT_PAREN *);
  265 (* LEFT_CURLEY *);
  266 (* RIGHT_CURLEY *);
  267 (* LEFT_BRACKET *);
  268 (* RIGHT_BRACKET *);
    0|]

let yytransl_block = [|
  261 (* IDENT *);
  262 (* BINARY_OP *);
  269 (* CONST *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\001\000\001\000\001\000\004\000\002\000\005\000\
\005\000\005\000\005\000\005\000\003\000\008\000\006\000\006\000\
\007\000\007\000\007\000\009\000\009\000\000\000"

let yylen = "\002\000\
\002\000\003\000\002\000\002\000\001\000\003\000\001\000\003\000\
\001\000\003\000\001\000\001\000\001\000\005\000\004\000\003\000\
\003\000\002\000\002\000\004\000\003\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\005\000\000\000\000\000\000\000\000\000\000\000\
\000\000\011\000\022\000\000\000\000\000\000\000\009\000\012\000\
\013\000\001\000\000\000\019\000\000\000\000\000\000\000\000\000\
\004\000\000\000\000\000\017\000\000\000\016\000\000\000\008\000\
\002\000\000\000\000\000\000\000\015\000\000\000\000\000\014\000\
\020\000\000\000\006\000"

let yydgoto = "\002\000\
\011\000\012\000\013\000\040\000\014\000\015\000\016\000\017\000\
\028\000"

let yysindex = "\005\000\
\001\000\000\000\000\000\001\000\254\254\009\255\008\255\012\255\
\021\255\000\000\000\000\026\255\001\000\031\255\000\000\000\000\
\000\000\000\000\037\255\000\000\021\255\005\255\023\255\001\000\
\000\000\021\255\021\255\000\000\035\255\000\000\039\255\000\000\
\000\000\031\255\255\254\033\255\000\000\037\255\001\000\000\000\
\000\000\041\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\048\255\000\000\000\000\
\000\000\000\000\024\255\000\000\000\000\000\000\000\000\002\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\038\255\000\000\000\000\000\000\032\255\000\000\000\000\
\000\000\000\000\000\000"

let yygindex = "\000\000\
\252\255\000\000\000\000\000\000\251\255\000\000\000\000\000\000\
\014\000"

let yytablesize = 270
let yytable = "\018\000\
\003\000\003\000\019\000\023\000\026\000\001\000\005\000\006\000\
\025\000\008\000\038\000\009\000\030\000\020\000\021\000\029\000\
\031\000\010\000\022\000\033\000\034\000\035\000\005\000\006\000\
\018\000\008\000\024\000\009\000\026\000\018\000\032\000\018\000\
\021\000\010\000\042\000\018\000\026\000\021\000\010\000\021\000\
\026\000\039\000\036\000\021\000\026\000\010\000\037\000\027\000\
\007\000\010\000\043\000\041\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\004\000\005\000\006\000\007\000\008\000\000\000\009\000\
\000\000\000\000\000\000\003\000\000\000\010\000"

let yycheck = "\004\000\
\000\000\000\000\005\001\009\000\006\001\001\000\002\001\003\001\
\013\000\005\001\012\001\007\001\008\001\005\001\007\001\021\000\
\022\000\013\001\007\001\024\000\026\000\027\000\002\001\003\001\
\001\001\005\001\001\001\007\001\006\001\006\001\008\001\008\001\
\001\001\013\001\039\000\012\001\006\001\006\001\001\001\008\001\
\006\001\009\001\008\001\012\001\006\001\008\001\008\001\011\001\
\001\001\012\001\010\001\038\000\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\001\001\002\001\003\001\004\001\005\001\255\255\007\001\
\255\255\255\255\255\255\010\001\255\255\013\001"

let yynames_const = "\
  EOF\000\
  SEMI\000\
  SCALAR\000\
  LIST\000\
  WHILE\000\
  LEFT_PAREN\000\
  RIGHT_PAREN\000\
  LEFT_CURLEY\000\
  RIGHT_CURLEY\000\
  LEFT_BRACKET\000\
  RIGHT_BRACKET\000\
  "

let yynames_block = "\
  IDENT\000\
  BINARY_OP\000\
  CONST\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun parser_env ->
    let _2 = (peek_val parser_env 0 : Pnode.block) in
    Obj.repr(
# 55 "genotype/perlGenotype/parser.mly"
               ( _2 )
# 187 "genotype/perlGenotype/parser.ml"
               : Pnode.block))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'statement) in
    let _3 = (peek_val parser_env 0 : Pnode.block) in
    Obj.repr(
# 57 "genotype/perlGenotype/parser.mly"
    ( debug "statement-semi-block" ; _1::_3 )
# 195 "genotype/perlGenotype/parser.ml"
               : Pnode.block))
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : 'statement) in
    Obj.repr(
# 59 "genotype/perlGenotype/parser.mly"
    ( debug "statement" ; _1::[] )
# 202 "genotype/perlGenotype/parser.ml"
               : Pnode.block))
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : 'loop) in
    let _2 = (peek_val parser_env 0 : Pnode.block) in
    Obj.repr(
# 61 "genotype/perlGenotype/parser.mly"
    ( debug "loop" ; _1::_2 )
# 210 "genotype/perlGenotype/parser.ml"
               : Pnode.block))
; (fun parser_env ->
    Obj.repr(
# 63 "genotype/perlGenotype/parser.mly"
    ( [] )
# 216 "genotype/perlGenotype/parser.ml"
               : Pnode.block))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : Pnode.block) in
    Obj.repr(
# 67 "genotype/perlGenotype/parser.mly"
    ( debug "Code Block" ; _2 )
# 223 "genotype/perlGenotype/parser.ml"
               : 'code_block))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'expression) in
    Obj.repr(
# 71 "genotype/perlGenotype/parser.mly"
    ( debug "expression" ; _1 )
# 230 "genotype/perlGenotype/parser.ml"
               : 'statement))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'expression) in
    Obj.repr(
# 75 "genotype/perlGenotype/parser.mly"
    ( _2 )
# 237 "genotype/perlGenotype/parser.ml"
               : 'expression))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'function_call) in
    Obj.repr(
# 77 "genotype/perlGenotype/parser.mly"
    ( debug "function call" ; _1 )
# 244 "genotype/perlGenotype/parser.ml"
               : 'expression))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'expression) in
    let _2 = (peek_val parser_env 1 : string) in
    let _3 = (peek_val parser_env 0 : 'expression) in
    Obj.repr(
# 79 "genotype/perlGenotype/parser.mly"
    ( debug ("BinOp " ^ _2) ; Pnode.Binop(_2,_1,_3) )
# 253 "genotype/perlGenotype/parser.ml"
               : 'expression))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 81 "genotype/perlGenotype/parser.mly"
    ( Pnode.Const(_1) )
# 260 "genotype/perlGenotype/parser.ml"
               : 'expression))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'identifier) in
    Obj.repr(
# 83 "genotype/perlGenotype/parser.mly"
    ( _1 )
# 267 "genotype/perlGenotype/parser.ml"
               : 'expression))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'while_loop) in
    Obj.repr(
# 87 "genotype/perlGenotype/parser.mly"
    ( _1 )
# 274 "genotype/perlGenotype/parser.ml"
               : 'loop))
; (fun parser_env ->
    let _3 = (peek_val parser_env 2 : 'expression) in
    let _5 = (peek_val parser_env 0 : 'code_block) in
    Obj.repr(
# 91 "genotype/perlGenotype/parser.mly"
    ( debug "while" ; Pnode.Loop("while",[_3],_5,[]) )
# 282 "genotype/perlGenotype/parser.ml"
               : 'while_loop))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : string) in
    let _3 = (peek_val parser_env 1 : 'expression) in
    Obj.repr(
# 95 "genotype/perlGenotype/parser.mly"
    ( Pnode.Apply(_1,_3) )
# 290 "genotype/perlGenotype/parser.ml"
               : 'function_call))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : string) in
    Obj.repr(
# 97 "genotype/perlGenotype/parser.mly"
    ( Pnode.Apply(_1,Pnode.Nothing) )
# 297 "genotype/perlGenotype/parser.ml"
               : 'function_call))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : string) in
    let _3 = (peek_val parser_env 0 : 'subscript) in
    Obj.repr(
# 101 "genotype/perlGenotype/parser.mly"
    ( debug (Printf.sprintf "Pnode.ListAt(%s,)" _2 );
      Pnode.ListAt(_2,_3) )
# 306 "genotype/perlGenotype/parser.ml"
               : 'identifier))
; (fun parser_env ->
    let _2 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 104 "genotype/perlGenotype/parser.mly"
    ( debug ("Scalar " ^ _2) ; Pnode.ScalarVar(_2) )
# 313 "genotype/perlGenotype/parser.ml"
               : 'identifier))
; (fun parser_env ->
    let _2 = (peek_val parser_env 0 : string) in
    Obj.repr(
# 106 "genotype/perlGenotype/parser.mly"
    ( debug ("List " ^ _2) ; Pnode.ListVar(_2) )
# 320 "genotype/perlGenotype/parser.ml"
               : 'identifier))
; (fun parser_env ->
    let _2 = (peek_val parser_env 2 : 'expression) in
    let _4 = (peek_val parser_env 0 : 'subscript) in
    Obj.repr(
# 110 "genotype/perlGenotype/parser.mly"
    ( _2::_4 )
# 328 "genotype/perlGenotype/parser.ml"
               : 'subscript))
; (fun parser_env ->
    let _2 = (peek_val parser_env 1 : 'expression) in
    Obj.repr(
# 112 "genotype/perlGenotype/parser.mly"
    ( _2::[] )
# 335 "genotype/perlGenotype/parser.ml"
               : 'subscript))
(* Entry block *)
; (fun parser_env -> raise (YYexit (peek_val parser_env 0)))
|]
let yytables =
  { actions=yyact;
    transl_const=yytransl_const;
    transl_block=yytransl_block;
    lhs=yylhs;
    len=yylen;
    defred=yydefred;
    dgoto=yydgoto;
    sindex=yysindex;
    rindex=yyrindex;
    gindex=yygindex;
    tablesize=yytablesize;
    table=yytable;
    check=yycheck;
    error_function=parse_error;
    names_const=yynames_const;
    names_block=yynames_block }
let block (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (yyparse yytables 1 lexfun lexbuf : Pnode.block)
