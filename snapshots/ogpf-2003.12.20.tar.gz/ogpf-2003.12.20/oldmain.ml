
let generations = 100
let popSize = 100
module Genotype = StringGenotype

(* First we'll create a population *)
module MainPop = Pop.Make (Genotype)

(* Display the intro *)
let intro () =
    "OGPF - OCaml Genetic Programming Framework\n"
  ^ "\n"
  ^ "See gpl.txt for copyright information.\n\n"

let one_iteration pop =
  try
    (* First we pull two random members of the population *)
    let a, pop = MainPop.pull_rand_member pop in
    let b, pop = MainPop.pull_rand_member pop in

    (* Then we evaluate them both *)
    let a_val = StringGenotype.evaluate a in
    let b_val = StringGenotype.evaluate b in

    (* Check to see if the first one is the winner *)
    if a_val == 0 then begin
      print_string "Found Winner!";
      print_newline();
      exit 0
    end;

    (* Check to see if our population is too small. If it is, BREED TIME! *)
    if MainPop.size pop < (popSize / 2) then
      let c = StringGenotype.crossover a b in
      let pop = MainPop.add_member pop a in
      let pop = MainPop.add_member pop b in
      MainPop.add_member pop c

    (* Check to see if our population is too big. If it is, DEATH TIME! *)
    else if MainPop.size pop > (popSize + (popSize * 2)) then
      let c = StringGenotype.rand() in
      MainPop.add_member pop c

    (* If member 'a' is too crappy, kill it *)
    (*
    else if a_val > 50 then
      MainPop.add_member pop b
    *)

    (* If 'a' is better than 'b' then lets just keep 'a' *)
    else if a_val < b_val (* && Random.int 100 < 90 *) then begin
      (* if Random.int 100 > (b_val - a_val) * 100 / a_val then *)
        MainPop.add_member pop a
      (* else
        MainPop.add_member pop b *)

    (* if 'a' is worse than 'b' then breed them, maybe 'b's goodness will wear
       off on 'a' *)
    end else if a_val > b_val then
      let c = StringGenotype.crossover a b in
      let pop = MainPop.add_member pop a in
      let pop = MainPop.add_member pop b in
      MainPop.add_member pop c

    (* Well... all things being equal... lets do something at random! *)
    else (* if a_val == b_val then *)
      if Random.int 100 < 50 then begin
        (* let b = StringGenotype.rand() in
        let c = StringGenotype.crossover a b in
        MainPop.add_member pop c *)
        MainPop.add_member pop a
      end else
        let c = StringGenotype.crossover a b in
        let pop = MainPop.add_member pop a in
        let pop = MainPop.add_member pop b in
        MainPop.add_member pop c
  with _ -> pop

let rec n_iterations pop n =
  (* if n <= 0 then pop
  else begin *)
    if n mod popSize == 0 then begin
      print_string "  generation #";
      let size = MainPop.size pop in
      print_int (n / size);
      print_string ":";
      print_int n;
      print_string "\tsize: ";
      print_int size;
      print_string "\tBest: ";
      let g, v = MainPop.best_val pop in
      print_int v;
      print_string "\t\t";
      StringGenotype.print g
    end;
    let pop = one_iteration pop in
    n_iterations pop (n + 1)
  (* end *)

(* Main routine *)
let _ =
  Random.self_init ();
  print_string (intro ());
  let p = MainPop.populate popSize in
  print_int (MainPop.size p);
  print_newline();
  MainPop.print p;
  print_newline();
  print_string "Doing 1000000 iterations...";
  print_newline();
  let p = n_iterations p 0 in
  print_string "New population:\n";
  MainPop.print p;
  print_newline()

