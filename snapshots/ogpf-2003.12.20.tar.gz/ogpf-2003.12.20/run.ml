
(* Run - controls a single run
 *
 * History / Notes
 *   2003.12.16
 *     - Created
 *)


(* First we'll create a population *)

module Make
  ( Geneotype: Genotype.Sig )
  ( Population: Population.Sig )
  ( SelectionMethod:  SelectionMethod.Sig )
  ( Problem: Problem.Sig )
  = struct

  let run() =
    let p = Population.populate 100 in
    Population.print p;
    print_newline()

end (* end of Make *)

