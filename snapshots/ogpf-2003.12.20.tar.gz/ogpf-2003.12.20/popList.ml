
(* pop.ml - Population of genomes *)

(* Holds the population.
 * 
 * This is a container for a bunch of genomes. It allows you to pull members
 * from the population and add them back in. Stuff like that.
 *
 * Maybe it will also keep history of the current members... I'm not sure if
 * that is appropriate for this location or not.
 *)

(* Nice little exception *)
exception Error of string

(* This describes the genotypes we can hold and what exactly
   we expect them to be able to do. *)
module type Genotype = sig
  type t
  val combine: t -> t -> t
  val rand: unit -> t
  val print: t -> unit
  val to_string: t -> string
  val evaluate: t -> int
end

(* Here we actually create a population of the given genotype *)
module Make ( Gene: Genotype ) = struct

  (* For now we'll just use a list *)
  type population = Gene.t list

  (* Return an empty population *)
  let empty: population = []

  (* Generate a new population from random genomes *)
  let rec populate size =
    if (size == 0) then []
    else (Gene.rand ())::(populate (size - 1))

  (* Calculate the size of the population *)
  let size pop = List.length pop

  (* Grab a random member of the population *)
  let pull_rand_member pop =
    let num = size pop in
    let nth = Random.int (num - 1) in
    let rec split n = function
      | f::(m::l) -> begin
        if (n == 0) then
          ([f], m, l)
        else
          let (new_f,m,l) = split (n - 1) (m::l) in
          ([f] @ new_f, m, l)
        end
      | _ -> begin
          print_string "GRR. Pop size: ";
          print_int num;
          print_string "\nnth: ";
          print_int nth;
          print_string "\nn: ";
          print_int n;
          print_newline();
          raise (Error "Pulling member problem... zero size population?")
        end
    in
    let (beginning, middle, endish) = split nth pop in
    (middle, (beginning @ endish))

  let add_member pop member =
    member::pop
 
  (* Auxillary printing function. Prints a numbered list of all the genomes *)
  let rec print_aux n = function
    | [] -> print_string "END"; print_newline(); (n - 1, 0)
    | h::t ->
      print_int n;
      print_string ": \"";
      print_string (Gene.to_string h);
      print_string "\"\t";
      let h_val = Gene.evaluate h in
      print_int h_val;
      print_string "\n";
      let total, sum = print_aux (n + 1) t in
      (total, sum + h_val)

  (* Print all the genomes *)
  let print g =
    let (total, sum) = print_aux 0 g in
    print_string "Total: ";
    print_int total;
    print_string "\tSum: ";
    print_int sum;
    print_string "\t\tAverage: ";
    print_float ((float sum) /. (float total));
    print_newline();

end


