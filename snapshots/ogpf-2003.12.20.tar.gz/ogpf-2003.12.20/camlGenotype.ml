(*
  This describes the genotypes we can hold and what exactly
  we expect them to be able to do. Others will have this defined

  module type Genotype = sig
    type t
    val combine: t -> t -> t
    val rand: unit -> t
    val print: t -> unit
    val to_string: t -> string
    val evaluate: t -> int
  end
*)

(* The core type, this must be named "t" *)
type t =
  | Variable of string
  | Function of Variable * t
  | Application of t * t
  | Definition of Variable * t
  | Boolean of bool
  | Number of int
  | Pair of t * t
  | Nil
  | Cons of t * t

(* Merge two functions...
   This is some sort of crossover *)
let combine f1 f2 = f1

let rand_var () =
  let n = Random.int 100 in
  "v" . (string_of_int n)

(* This might not make valid programs! But thats OK *)
let rec rand () =
  let n = Random.int 9 in
  match n with
  | 0 -> rand_var()
  | 1 -> Function(rand_var(), rand())
  | 2 -> Application(rand(), rand())
  | 3 -> Definition(rand_var(), rand())
  | 4 -> Boolean(Random.int 2 = 0)
  | 5 -> Number(Random.int 100)
  | 6 -> Pair(rand(), rand())
  | 7 -> Nil
  | 8 -> Cons(rand(), rand())
  | _ -> Nil


let rec pprint
