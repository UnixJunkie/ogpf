
(* This describes the genotypes we can hold and what exactly
   we expect them to be able to do. *)
(*module type Genotype = sig
  type t
  val combine: t -> t -> t
  val randInstance: int -> t
  val print: t -> unit
  val to_string: t -> string
end*)


(*module type Population = sig
  type t
  val pull_random_member:
*)

(* Here we actually create a population of the given genotype *)
module Make ( Geneotype: Genotype.Sig ) ( Gene': Genotype.Sig ) = struct

  let print n m =
    print_string (Geneotype.to_string n);
    print_string (Gene'.to_string m);
    print_newline()

end


module Bleh = Make (StringGenotype) (StringGenotype)
let _ =
  Bleh.print "hello" "dude";
  print_string "done!\n"
  
