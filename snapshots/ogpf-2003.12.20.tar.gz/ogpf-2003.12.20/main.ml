
(* Main - entrypoint for a GP program based on the OGPF.
 *
 * History / Notes
 *   2003.12.18
 *     - Compiles and runs the "Roses are red" problem using new framework! YAY
 *   2003.12.16
 *     - Moving to new framework structure
 *     - This file should be minimal, deligating work elsewhere
 *)

(* First we open the RunSpecification, importing everything. This will tell us
  what genotype and selection-method to use, and what problem we will be
  solving *)
open RunSpecification

(* Function to display the intro *)
let intro () = print_string (
    "OGPF - OCaml Genetic Programming Framework\n"
  ^ "\n"
  ^ "See gpl.txt for copyright information.\n\n")

(* First we'll create a population module for the desired genotype *)
module Population = Pop.Make (Genotype)
module Problem = Problem.Make (Genotype)

(* Set up the run module *)
module TheRun = SelectionMethod.Make (Genotype) (Population) (Problem)

let _ =
  (* Print out the intro *)
  intro();
(*  print_string "Hrm.";
  print_string (Soundex.soundex "hello my friend");
  print_newline();
  exit 0 *)
  (* Initialize the random number generator *)
  Random.self_init();
  (* Initialize the run *)
  let r = TheRun.run() in
  (*print_int parameter.max_population; *)
  print_newline()

