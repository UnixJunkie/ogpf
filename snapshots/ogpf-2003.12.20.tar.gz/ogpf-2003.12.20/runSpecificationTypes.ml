
(* runSpecificationTypes.ml - specify some types which might be used in the run
 *   specification
 *
 * History / Notes
 *   2003.12.16
 *     - Created
 *)

type ptype = {
  max_population: int;
  min_population: int;
}

